﻿using System;

namespace AuthorProblem
{
    [Author("Miro")]
    public class StartUp
    {
        [Author("Mirko")]
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
