﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Wild_Farm.Foods
{
    public class Fruit : Food
    {
        public Fruit(int quantity) : base(quantity)
        {
        }
    }
}
