﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FakeAxeAndDummy.Tests.Fakes
{
    public class FakeWeapon : IWeapon
    {
       
        public void Attack(ITarget target)
        {

        }
     
    }
}
