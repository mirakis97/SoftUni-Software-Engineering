﻿namespace P06FoodShortage
{
    public interface IBirthable
    {
        string Birthdate { get; }
    }
}