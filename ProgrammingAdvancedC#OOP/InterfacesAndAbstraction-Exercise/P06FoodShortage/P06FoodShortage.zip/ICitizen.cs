﻿namespace P06FoodShortage
{
    public interface ICitizen : IPerson,IIdentifiable,IBirthable
    {
        
    }
}