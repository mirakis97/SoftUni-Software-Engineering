﻿namespace P06FoodShortage
{
    public interface IIdentifiable
    { 
        string Id { get; }
    }
}