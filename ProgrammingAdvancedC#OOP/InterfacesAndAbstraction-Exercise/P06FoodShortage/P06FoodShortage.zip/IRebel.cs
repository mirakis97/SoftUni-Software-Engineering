﻿namespace P06FoodShortage
{
    public interface IRebel : IPerson
    {
        string Group { get; }
    }
}