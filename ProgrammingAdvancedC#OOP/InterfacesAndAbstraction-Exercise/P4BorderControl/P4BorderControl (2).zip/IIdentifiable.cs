﻿namespace P4BorderControl
{
    public interface IIdentifiable
    { 
        string Id { get; }
    }
}