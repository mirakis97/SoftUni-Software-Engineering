﻿namespace P4BorderControl
{
    public interface IBirthable
    {
        string Birthdate { get; }
    }
}