﻿namespace P4BorderControl
{
    public interface IRobot : IIdentifiable
    { 
        string Model { get; }
    }
}