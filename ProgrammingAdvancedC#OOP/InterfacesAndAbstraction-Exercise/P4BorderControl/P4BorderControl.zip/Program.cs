﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace P4BorderControl
{
    public class Program
    {
        static void Main(string[] args)
        {
            List<IIdentifiable> identifables = new List<IIdentifiable>();

            while (true)
            {
                string line = Console.ReadLine();

                if (line == "End")
                {
                    break;
                }

                string[] parts = line.Split(" ", StringSplitOptions.RemoveEmptyEntries);

                if (parts.Length == 3)
                {
                    string name = parts[0];
                    int age = int.Parse(parts[1]);
                    string id = parts[2];
                    identifables.Add(new Citizen(name, age, id));
                }
                else
                {
                    string model = parts[0];
                    string id = parts[1];

                    identifables.Add(new Robot(id,model));
                }

            }

            string fillterId = Console.ReadLine();

            List<IIdentifiable> filtred = identifables.Where(p => p.Id.EndsWith(fillterId)).ToList();

            foreach (var identifalbe in filtred)
            {
                Console.WriteLine(identifalbe.Id);
            }
        }
    }
}
