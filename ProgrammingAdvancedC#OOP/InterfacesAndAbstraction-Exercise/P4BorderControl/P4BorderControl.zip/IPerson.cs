﻿namespace P4BorderControl
{
    public interface IPerson : IIdentifiable
    {
       string Name { get; }
       int Age { get; }
    }
}