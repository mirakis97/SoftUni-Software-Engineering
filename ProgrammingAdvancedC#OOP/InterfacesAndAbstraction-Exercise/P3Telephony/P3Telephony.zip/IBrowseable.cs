﻿namespace P3Telephony
{
    public interface IBrowseable
    {
        string Browse(string url);
    }
}