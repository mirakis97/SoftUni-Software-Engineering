﻿using AquaShop.IO.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace AquaShop.IO
{
    public class StringBuilderWriter : IWriter
    {
        public StringBuilder sb = new StringBuilder();

        public void Write(string message)
        {
            sb.AppendLine(message);
        }

        public void WriteLine(string message)
        {
            sb.AppendLine(message);
        }
    }
}
