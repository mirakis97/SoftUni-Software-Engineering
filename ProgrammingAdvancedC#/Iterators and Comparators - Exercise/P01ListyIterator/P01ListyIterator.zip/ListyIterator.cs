﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace P01ListyIterator
{
   public class ListyIterator<T> 
    {
        private List<T> list;
        private int index;

        public ListyIterator(params T[] list)
        {
            this.list = new List<T>(list);
            this.index = 0;
        }

        public bool Move()
        {
            if (this.index + 1 < this.list.Count)
            {
                this.index++;
                return true;
            }

            return false;
        }

        public bool HasNext()
        {
            return this.index + 1 < this.list.Count;
        }

        public void Print()
        {
            if (this.list.Count == 0)
            {
                throw new InvalidOperationException("Invalid Operation!");
            }
            else
            {
                Console.WriteLine(this.list[this.index]);

            }
        }
    }
}
