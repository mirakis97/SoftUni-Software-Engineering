﻿namespace _01.Inventory.Models
{
    public enum Category
    {
        Light,
        Medium,
        Heavy
    }
}
