﻿namespace _01._BrowserHistory
{
    using System;
    using System.Collections.Generic;
    using _01._BrowserHistory.Interfaces;

    public class BrowserHistory : IHistory
    {
        private Node<ILink> head;
        private Node<ILink> _tail;



        public int Size { get; private set; }

        public void Clear()
        {
            this.head = this._tail = null;
            this.Size = 0;
        }

        public bool Contains(ILink link)
        {
            return this.GetByUrl(link.Url) != null;
        }

        public ILink DeleteFirst()
        {
            throw new NotImplementedException();
        }

        public ILink DeleteLast()
        {
            throw new NotImplementedException();
        }

        public ILink GetByUrl(string url)
        {
            var currElement = this.head;
            while (currElement != null)
            {
                if (currElement.Value.Url == url)
                {
                    return currElement.Value;
                }
                currElement = currElement.NextChild;
            }
            return null;
        }

        public ILink LastVisited()
        {
            this.IsEmpty();
            return this.head.Value;
        }

        public void Open(ILink link)
        {
            var linkToPut = new Node<ILink>(link);
            if (this.Size == 0)
            {
                this.head = this._tail = linkToPut;
            }
            else
            {
                this.head.PreviouseChild = linkToPut;
                linkToPut.NextChild = this.head;
                this.head = linkToPut;
            }
            this.Size++;
        }

        public int RemoveLinks(string url)
        {
            throw new NotImplementedException();
        }

        public ILink[] ToArray()
        {
            throw new NotImplementedException();
        }

        public List<ILink> ToList()
        {
            throw new NotImplementedException();
        }

        public string ViewHistory()
        {
            throw new NotImplementedException();
        }


        private void IsEmpty()
        {
            if (this.Size == 0)
            {
                throw new InvalidOperationException("Browser history is empty!");
            }
        }
    }
}
